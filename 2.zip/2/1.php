<?php

$n1 = 80;
$n2 = 90;
$n3 = 85;

$rata_rata = ($n1 + $n2 + $n3) / 3;

echo "Nilai Ujian 1: $n1 <br>";
echo "Nilai Ujian 2: $n2 <br>";
echo "Nilai Ujian 3: $n3 <br>";
echo "Rata-rata Nilai: " . number_format($rata_rata, 2);
?>
